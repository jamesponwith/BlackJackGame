/*
 * Author: James Ponwith
 * Black Jack Game
 *
 */

import javafx.geometry.*;
import javafx.stage.*;
import javafx.scene.*;
import java.util.*;
import java.io.File;
import javafx.geometry.Insets;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Background;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.text.Font;
import javafx.scene.shape.*;

/**
 * This is a simplified version of a common card game, "21"
 * for Assignment 4.
 *
 * The players take turns requesting cards, trying to get
 * as close to 21 as possible, but not going over 21. A player
 * may stand (ask for no more cards). Once a player has passed,
 * he or she cannot later ask for another card. When all three
 * players have passed, the game ends.
 *
 * The winner is the player who has come closest to 21 without
 * exceeding it. In the case of a tie, or if everyone goes over
 * 21, no one wins.
 *
 * Per the assignment, we assume exactly three players. The game
 * is only played once.
 */
public class Game extends Application {

	// An ArrayList to store the 3 Player objects
	static ArrayList<Player> players;

	// An ArrayList to store the deck of cards
	static ArrayList<Card> cardDeck;
	static ArrayList<Card> usedCards;
	static int cardsLeftInDeck = 52;
	static int currentPlayer = 0;

	Scene scene;
	static Scene pokerGameScene;

	public void start(Stage window) {

		players = new ArrayList<Player> ();
		initPlayers(players);

		cardDeck = new ArrayList<Card> ();
		initDeck(cardDeck);

		/* Creating layours for the two scenes (start page and poker table)*/
		BorderPane startPageLayout = new BorderPane();
		BorderPane pokerGameLayout = new BorderPane();
		StackPane centerStack = new StackPane();
		BorderPane centerPieceBorderPane = new BorderPane();
		centerPieceBorderPane.setPadding(new Insets(10, 10, 10, 10));

		/* Setting up boxs to for cards to be placed in */
		VBox vboxRight = new VBox(10);
		vboxRight.setPadding(new Insets(10,10,10,10));
		vboxRight.setAlignment(Pos.CENTER);

		HBox hboxTop = new HBox(10);
		hboxTop.setPadding(new Insets(10,10,10,10));
		hboxTop.setAlignment(Pos.CENTER);

		VBox vboxLeft = new VBox(10);
		vboxLeft.setPadding(new Insets(10,10,10,10));
		vboxLeft.setAlignment(Pos.CENTER);

		HBox hboxBottom = new HBox(10);
		hboxBottom.setPadding(new Insets(10,10,10,10));
		hboxBottom.setAlignment(Pos.CENTER);

		HBox hboxCenter = new HBox(80);
		hboxCenter.setAlignment(Pos.CENTER);

		/* Center piece of table for cosmetics */
		Ellipse centerPiece = new Ellipse();
		centerPiece.setCenterX(150.0f);
		centerPiece.setCenterY(150.0f);
		centerPiece.setRadiusX(250.0f);
		centerPiece.setRadiusY(125.0f);
		centerPiece.setFill(Color.GREEN);
		centerPiece.setStroke(Color.BLACK);

		/* Labels for the table and center piece for cosmetics */
		Label label1 = new Label("Dealer (Top)");
		Label label2 = new Label("Player 2 (Bottom)");
		Label label3 = new Label("Player 3 (Left)");
		Label label4 = new Label("Player 1 (Right)");
		centerPieceBorderPane.setRight(label4);
		centerPieceBorderPane.setTop(label1);
		centerPieceBorderPane.setLeft(label3);
		centerPieceBorderPane.setBottom(label2);
		centerPieceBorderPane.setCenter(centerPiece);

		hboxCenter.getChildren().add(centerPieceBorderPane);

 /* Create start button
	* Functionality:
	* Start button to swap scenes from welcome page to poker table
	* Deal players cards
	* Open new window for Player 1's move
	*/
	Button startButton;
	startButton = new Button("Start Game");
			try {
				startButton.setOnAction(e-> {
					window.setScene(pokerGameScene);
					DisplayBox.display("Player Box", "Would you like to hit or pass?");
					});
				startPageLayout.setCenter(startButton);

			}catch(Exception e) {
				System.out.println(e.getMessage());
			}

		/* Generate and assign background image for the start page */
		try{
			String url = "startPageBackground/WelcomePage.jpg";
			Image backImage = new Image(url);

			BackgroundSize backgroundSize = new BackgroundSize(100, 100, true,
			true, true, false);

			BackgroundImage backgroundImage = new BackgroundImage(backImage,
			BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT,
			BackgroundPosition.CENTER, backgroundSize);

			Background background = new Background(backgroundImage);
			startPageLayout.setBackground(background);

		} catch(Exception e) {
			System.out.println(e.getMessage());
		}

		/* Deals cards to players hand */
		assignPlayersCards();

		/* Place the card images onto the poker table scene */
		displayCardsRight(vboxRight, players);
		displayCardsTop(hboxTop, players);
		displayCardsLeft(vboxLeft, players);
		displayCardsBottom(hboxBottom, players);

		Button flipDealerCard = new Button("Update Board");
		try {
			flipDealerCard.setOnAction(e-> {
					hboxTop.getChildren().clear();
					hboxBottom.getChildren().clear();
					vboxRight.getChildren().clear();
					vboxLeft.getChildren().clear();
					updateDisplayCardsTop(hboxTop, players);
					displayCardsRight(vboxRight, players);
					displayCardsLeft(vboxLeft, players);
					displayCardsBottom(hboxBottom, players);
				});
			hboxBottom.getChildren().add(flipDealerCard);

		}catch(Exception e) {
			System.out.println(e.getMessage());
		}

		Button winnerButton = new Button("Check Winners");
		try {
			winnerButton.setOnAction(e-> {
				WinnerBox.displayWinners("Winners");
				});
			vboxLeft.getChildren().add(winnerButton);

		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		centerStack.getChildren().addAll(hboxCenter, winnerButton);
		pokerGameLayout.setTop(hboxTop);
		pokerGameLayout.setBottom(hboxBottom);
		pokerGameLayout.setRight(vboxRight);
		pokerGameLayout.setLeft(vboxLeft);
		pokerGameLayout.setCenter(centerStack);
		pokerGameLayout.setStyle("-fx-background-color: transparent;");

		// Initialize the two scenes
		scene = new Scene(startPageLayout, 960, 600);
		pokerGameScene = new Scene(pokerGameLayout, 960, 650, Color.GREEN);

		window.setTitle("Blackjack"); // Set the stage title
		window.setScene(scene); // Place the scene in the stage
		window.centerOnScreen();

		window.show(); // Display the stage
	}

	/* Initializes the deck of cards */
	public static void initDeck(ArrayList<Card> d) {

		String[] suits = new String[] {"C", "D", "H", "S"};
		String[] faces = new String[] {"J", "Q", "K", "A"};

		for (String s: suits) {
	        for(int i = 2; i < 11; i++) {
	        		// Create and add a new card for each of the numbered cards
	        		String name = i + s;
	        		String imagePath = "images/" + name + ".png";
	        		Card c = new Card(name, imagePath, i);
	        		d.add(c);
	        }
	    }

		for (String s:suits) {
	        for(String f:faces) {
	        		// Create and add a new card for each of the face cards
	        		String name = f + s;
	        		String imagePath = "images/" + name + ".png";

	        		if( f.equals("A"))
	        			d.add(new Card(name, imagePath, 11));
	        		else
	        			d.add(new Card(name, imagePath, 10));
	        }
	    }
	}

	/* Creates three players and a dealer
	 * @param takes in the arraylist that players will be placed in
	 * @return the arraylist of initialized players
	 */
	public ArrayList<Player> initPlayers(ArrayList<Player> players) {

		players.add(new Player("Player 1"));
		players.add(new Player("Player 2"));
		players.add(new Player("Player 3"));
		players.add(new Player("Dealer"));

		return players;
	}

	/* Generates a random number
	 * @param none
	 * @return a random number to be used for a card index
	 */
	public static int randomCardGenerator() {
		Random rand = new Random();
		int randomCard = rand.nextInt(cardsLeftInDeck);

		return randomCard;
	}

	/* Assigns 2 cards to 4 player objects using nested loops
	 * @param No parameters
	 * @return No return
	 */
	public void assignPlayersCards() {

		for(int i = 0; i < 4; i++) {
			for(int x = 0; x < 2; x++) {
					int cardIndex = randomCardGenerator();
					Card c = cardDeck.get(cardIndex);
					players.get(i).hand.addCard(c);
					players.get(i).hand.updateTotalValue();
					// System.out.println(players.get(i).getScore());
					cardDeck.remove(cardIndex);
					cardsLeftInDeck--;
			}
		}
	}

/* Return Player 1's Cards to display
 * @param takes in an HBox
 * @param Array of players to place the images onto the poker table scene
 * @return an HBox with the images of the players cards attached
 */
	public VBox displayCardsRight(VBox vboxRight, ArrayList<Player> players) {
		/* Generate and place card in hboxTop */
		for(int i = 0; i < players.get(0).hand.getHand().size(); i++) {
			try {

				Image pic = new Image(new FileInputStream(players.get(0).hand.getHand().get(i).getImagePath()), 70, 100, false, false);
				ImageView cardImage = new ImageView();
				cardImage.setImage(pic);
				vboxRight.getChildren().add(cardImage);
			}
			catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}
		return vboxRight;
	}

/* Return Player 2's Cards to display
 * @param takes in an HBox
 * @param Array of players to place the images onto the poker table scene
 * @return an HBox with the images of the players cards attached
 */
	public HBox displayCardsBottom(HBox hboxBottom, ArrayList<Player> players) {
		/* Generate and place card in hboxTop */
		for(int i = 0; i < players.get(1).hand.getHand().size(); i++) {
			try {

				Image pic = new Image(new FileInputStream(players.get(1).hand.getHand().get(i).getImagePath()), 70, 100, false, false);
				ImageView cardImage = new ImageView();
				cardImage.setImage(pic);
				hboxBottom.getChildren().add(cardImage);
			}
			catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}
		return hboxBottom;
	}

	/* Return Player 3's Cards to display
	* @param takes in an HBox
	* @param Array of players to place the images onto the poker table scene
	* @return an VBox with the images of the players cards attached
	*/
		public VBox displayCardsLeft(VBox vboxLeft, ArrayList<Player> players) {
			/* Generate and place card in hboxTop */
			for(int i = 0; i < players.get(2).hand.getHand().size(); i++) {
				try {

					Image pic = new Image(new FileInputStream(players.get(2).hand.getHand().get(i).getImagePath()), 70, 100, false, false);
					ImageView cardImage = new ImageView();
					cardImage.setImage(pic);
					vboxLeft.getChildren().add(cardImage);
				}
				catch (Exception e) {
					System.out.println(e.getMessage());
				}
			}
			return vboxLeft;
		}

		/* Return Dealer's Cards to display
		 * @param takes in an HBox
		 * @param Array of players to place the images onto the poker table scene
		 * @return an HBox with the images of the players cards attached
		 */
			public HBox displayCardsTop(HBox hboxTop, ArrayList<Player> players) {
				/* Generate and place card in hboxTop */
				try {

					Image pic = new Image(new FileInputStream("images/backOfCard.png"), 70, 100, false, false);
					ImageView cardImage = new ImageView();
					cardImage.setImage(pic);
					hboxTop.getChildren().add(cardImage);
				}
				catch (Exception e) {
					System.out.println(e.getMessage());
				}

				for(int i = 1; i < players.get(3).hand.getHand().size(); i++) {
					try {

						Image pic = new Image(new FileInputStream(players.get(3).hand.getHand().get(i).getImagePath()), 70, 100, false, false);
						ImageView cardImage = new ImageView();
						cardImage.setImage(pic);
						hboxTop.getChildren().add(cardImage);
					}
					catch (Exception e) {
						System.out.println(e.getMessage());
					}
				}
				return hboxTop;
			}

			/* Return Dealer's Cards to display
			 * @param takes in an HBox
			 * @param Array of players to place the images onto the poker table scene
			 * @return an HBox with the images of the players cards attached
			 */
			 public static HBox updateDisplayCardsTop(HBox hboxTop, ArrayList<Player> players) {

				 for(int i = 0; i < players.get(3).hand.getHand().size(); i++) {
					 try {

						 Image pic = new Image(new FileInputStream(players.get(3).hand.getHand().get(i).getImagePath()), 70, 100, false, false);
						 ImageView cardImage = new ImageView();
						 cardImage.setImage(pic);
						 hboxTop.getChildren().add(cardImage);
					 }
					 catch (Exception e) {
						 System.out.println(e.getMessage());
					 }
				 }
				 return hboxTop;
			 }

			/* Retrieves a card image and returns it to an hbox
			 * @param The imagepath to desired card
			 * @param takes in an HBox
			 * @return an updated hbox
			 */
			public static HBox addCardPicture(String url, HBox hbox) {
				ImageView cardImage = new ImageView();

				try {
					Image pic = new Image(new FileInputStream(url), 70, 100, false, false);
					cardImage.setImage(pic);
					hbox.getChildren().add(cardImage);
				} catch(Exception e) {
					System.out.println(e.getMessage());
				}
				return hbox;
			}

    /**
     * The main method is only needed for the IDE with limited
     * JavaFX support. Not needed for running from the command line.
     */
  public static void main(String[] args) {
      launch(args);
  }
}
