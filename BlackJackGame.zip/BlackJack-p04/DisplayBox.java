import javafx.geometry.*;
import javafx.stage.*;
import javafx.scene.*;
import java.util.*;
import java.io.File;
import javafx.geometry.Insets;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Background;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.text.Font;
import javafx.scene.shape.*;
/**
 * Represents the alert boxs used for user decisions.
 */

public class DisplayBox {

	/* Creates a new window for the players individual turns. The window
	 * provides a hit and hold button along with a display of their score
	 * and current hand of cards.
	 * @param String for the title of the window
	 * @param String for a message to prompt what action the user should complete
	 * @return no return but spawns a window for action
	 */
	public static void display(String title, String message) {

		Stage inputBox = new Stage();

		BorderPane layout = new BorderPane();
		layout.setPadding(new Insets(10,10,10,10));

		HBox hboxBot = new HBox(5);
		hboxBot.setAlignment(Pos.CENTER);

		HBox hboxCenter = new HBox(5);
		hboxCenter.setAlignment(Pos.CENTER);

		//inputBox.initModality(Modality.APPLICATION_MODAL);
		inputBox.setTitle(title);
		inputBox.setMinWidth(400);
		Label label = new Label();
		label.setText(message);

		/* Hit button */
		Button hitButton = new Button("Hit");
		hitButton.setOnAction(e -> {

			/* Check if the player has busted than if the player is the dealer */
			if(Game.players.get(Game.currentPlayer).getScore() <= 21 && Game.currentPlayer != 3){
				int cardIndex = Game.randomCardGenerator();
				Card c = Game.cardDeck.get(cardIndex);
				Game.players.get(Game.currentPlayer).hand.addCard(c);
				Game.addCardPicture(c.getImagePath(), hboxCenter);
				layout.setCenter(hboxCenter);
				Game.players.get(Game.currentPlayer).hand.updateTotalValue();

				/* Checks players new score and if busted, moves on, if not allows another
				 * action
				 */
				if(Game.players.get(Game.currentPlayer).getScore() <= 21) {
					Game.cardDeck.remove(cardIndex);
					Game.cardsLeftInDeck--;
					inputBox.close();
					DisplayBox.display("Player Box", "Would you like to hit or pass?");
				}

				/* If player busts it will set boolean to true and swap to next player */
				else {
					Game.players.get(Game.currentPlayer).busted = true;
					inputBox.close();
					Game.currentPlayer++;
					if(Game.currentPlayer != 3 ) {
						DisplayBox.display("Player Box", "Would you like to hit or pass?");
					}

					/* If it is the dealer (player 3) than add cards until they are over
					 * 16
					 */
					if(Game.currentPlayer == 3 ) {
						do {
							int cardIndexDealer = Game.randomCardGenerator();
							Card newCard = Game.cardDeck.get(cardIndexDealer);
							Game.players.get(3).hand.addCard(newCard);
							Game.players.get(3).hand.updateTotalValue();
							if(Game.players.get(3).getScore() > 21) {
								Game.players.get(3).busted = true;
							}
						}while(Game.players.get(3).getScore() <= 16);
					}
				}
			}
			else {
				Game.players.get(Game.currentPlayer).busted = true;
				inputBox.close();
				Game.currentPlayer++;
				if(Game.currentPlayer != 3 ) {
					DisplayBox.display("Player Box", "Would you like to hit or pass?");
				}
				if(Game.currentPlayer == 3 ) {
					do {
						int cardIndexDealer = Game.randomCardGenerator();
						Card newCard = Game.cardDeck.get(cardIndexDealer);
						Game.players.get(3).hand.addCard(newCard);
						Game.players.get(3).hand.updateTotalValue();
						System.out.println(Game.players.get(3).getScore());
					}while(Game.players.get(3).getScore() <= 16);
				}
			}
		});
		hitButton.setStyle("-fx-background-color: #ffd700;");

		/* Hold button
		 * The button jumps to the next player and only calls display another box
		 * if the game has not yet reached the dealer. Once reaching dealer it
		 * will state who wins and complete the dealers moves.
		 */
		Button passButton = new Button("Hold");
		passButton.setOnAction(e -> {
			inputBox.close();
			Game.currentPlayer++;
			if(Game.currentPlayer != 3) {
				DisplayBox.display("Player Box", "Would you like to hit or pass?");
			}
			if(Game.currentPlayer == 3 ) {
				do {
					int cardIndexDealer = Game.randomCardGenerator();
					Card newCard = Game.cardDeck.get(cardIndexDealer);
					Game.players.get(3).hand.addCard(newCard);
					Game.players.get(3).hand.updateTotalValue();
				}while(Game.players.get(3).getScore() <= 16);
			}
		});
		passButton.setStyle("-fx-background-color: #32cd32;");
		hboxBot.getChildren().addAll(hitButton, passButton);

		VBox vboxLeft = new VBox(5);
		String score = Integer.toString(Game.players.get(Game.currentPlayer).getScore());
		Label labelScore = new Label(score);
		vboxLeft.getChildren().add(labelScore);

		/* Imports the current players cards to the display window, Display box is a recurring
		 * class meaning this chunck of code is doing the same job for each instance
		 * for the players respective hands
		 */
		for(int i = 0; i < Game.players.get(Game.currentPlayer).hand.getHand().size(); i++) {
			try {
				Image pic = new Image(new FileInputStream(Game.players.get(Game.currentPlayer).hand.getHand().get(i).getImagePath()), 70, 100, false, false);
				ImageView cardImage = new ImageView();
				cardImage.setImage(pic);
				hboxCenter.getChildren().add(cardImage);
			}catch(Exception e) {
				System.out.println(e.getMessage());
			}
		}

		int playerLabelIndex = Game.currentPlayer + 1;
		Label label1 = new Label("Player " + playerLabelIndex);
		layout.setTop(label1);
		layout.setBottom(hboxBot);
		layout.setLeft(vboxLeft);
		layout.setCenter(hboxCenter);

		Scene scene = new Scene(layout, 400, 300);
		inputBox.setScene(scene);
		inputBox.show();
	}
}
