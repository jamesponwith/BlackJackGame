import javafx.geometry.*;
import javafx.stage.*;
import javafx.scene.*;
import java.util.*;
import java.io.File;
import javafx.geometry.Insets;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Background;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.text.Font;
import javafx.scene.shape.*;

public class WinnerBox {

  /*
  * This is a class to call a window to display the winners, unfortunatley it
  * does not work correctly.
  * @param takes in a String for a title
  * @return spawns a window upon a button click 
  */
  public static void displayWinners(String title) {

    ArrayList<Player> winnerList = new ArrayList<>();
    String message = " ";

		Stage winnerWindow = new Stage();

		BorderPane winnerLayout = new BorderPane();
		winnerLayout.setPadding(new Insets(10,10,10,10));

		HBox hboxCenter = new HBox(5);
		hboxCenter.setAlignment(Pos.CENTER);


		//inputBox.initModality(Modality.APPLICATION_MODAL);
		winnerWindow.setTitle(title);
		winnerWindow.setMinWidth(400);
		Label labelWinner = new Label();

    for(int i = 0; i < 3; i++) {
      if(Game.players.get(i).busted == false) {
        if(Game.players.get(i).getScore() >= Game.players.get(3).getScore()) {
          winnerList.add(Game.players.get(i));
      }

        for(int j = 0; j < 3; j++) {
          if(Game.players.get(j).busted == false && Game.players.get(3).busted == true) {
            winnerList.add(Game.players.get(j));
          }
        }
    }
  }

    for(int x = 0; x < winnerList.size(); x++) {
      message += winnerList.get(x).getName() + " ";
    }

for(int i = 0; i < 3; i++) {
    if(Game.players.get(3).getScore() <= 21 && Game.players.get(3).getScore() > Game.players.get(i).getScore()) {
      message = "Dealer wins";
    }
  }

    labelWinner.setText(message);
    winnerLayout.setCenter(labelWinner);

    Scene winnerScene = new Scene(winnerLayout, 400, 300);
		winnerWindow.setScene(winnerScene);
		winnerWindow.show();
  }
}
